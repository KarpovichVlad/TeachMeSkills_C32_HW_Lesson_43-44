create function update_modified_column() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated = NOW();
    RETURN NEW;
END;
$$;

alter function update_modified_column() owner to postgres;

